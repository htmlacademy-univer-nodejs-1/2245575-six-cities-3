const Spinner = (): JSX.Element => <div>Загрузка...</div>;

export default Spinner;
