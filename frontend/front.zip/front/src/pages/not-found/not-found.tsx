const NotFound = (): JSX.Element => <div>Not Found 404</div>;

export default NotFound;
